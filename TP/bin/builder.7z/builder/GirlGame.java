package builder;

public class GirlGame extends Gift {

    private String GIRL = "Girl game";
    private float price = 0.00f;
    
    /**
     * @return
     */
    public String getName() {
        // TODO implement here
        return this.GIRL;
    }
    /**
     * @return
     */
    public float getPrice() {
        // TODO implement here
        return this.price;
    }

}