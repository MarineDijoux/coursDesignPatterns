package builder;

public class BoyGame extends Gift {

    private String BOY = "Boy game";
    private float price = 0.00f;
    
    /**
     * @return
     */
    public String getName() {
        // TODO implement here
        return this.BOY;
    }
    /**
     * @return
     */
    public float getPrice() {
        // TODO implement here
        return this.price;
    }

}