package builder;

public class Bottle implements Packaging {

    private String BOTTLE = "Bottle";

    /**
     * @return
     */
    public String getPack() {
        // TODO implement here
        return this.BOTTLE;
    }

}