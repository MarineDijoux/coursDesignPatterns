package builder;

public class Coke extends Drink {

    private String COKE = "Coke";
    private float price = 2.00f;

    /**
     * @return
     */
    public String getName() {
        // TODO implement here
        return this.COKE;
    }
    /**
     * @return
     */
    public float getPrice() {
        // TODO implement here
        return this.price;
    }

}