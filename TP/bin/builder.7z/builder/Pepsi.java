package builder;

public class Pepsi extends Drink {

    private String PEPSI = "Pepsi";
    private float price = 1.50f;

    /**
     * @return
     */
    public String getName() {
        // TODO implement here
        return this.PEPSI;
    }
    /**
     * @return
     */
    public float getPrice() {
        // TODO implement here
        return this.price;
    }

}