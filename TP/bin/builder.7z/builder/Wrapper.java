package builder ;

public class Wrapper implements Packaging {

    private String WRAPPER = "Wrapper";

    /**
     * @return
     */
    public String getPack() {
        // TODO implement here
        return this.WRAPPER;
    }

}