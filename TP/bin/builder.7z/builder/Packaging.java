package builder ;

public interface Packaging {

    /**
     * @return
     */
    public String getPack();

}